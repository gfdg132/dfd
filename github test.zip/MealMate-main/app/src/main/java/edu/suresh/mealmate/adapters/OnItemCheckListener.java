package edu.suresh.mealmate.adapters;

public interface OnItemCheckListener {
    void onItemCheckChanged();
}
