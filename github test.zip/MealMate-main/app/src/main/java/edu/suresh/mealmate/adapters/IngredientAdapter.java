package edu.suresh.mealmate.adapters;

public class IngredientAdapter {
}
