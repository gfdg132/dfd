package edu.suresh.mealmate.fragments;

public interface ProgressUpdateListener {
    void onProgressUpdated(int progress, String summaryText);
}