package edu.suresh.mealmate.utils;

public class APIKey {

    public static String GOOGLE_API_KEY = "YOUR_KEY";

}
