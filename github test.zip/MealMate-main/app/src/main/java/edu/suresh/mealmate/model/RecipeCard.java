package edu.suresh.mealmate.model;

import java.io.Serializable;
import java.util.List;

public class RecipeCard implements Serializable {
//    private String title;
//    private String imageUrl;
//    private int ingredientCount;
//    private int stepCount;
//    private String cookTime;
//    private List<String> ingredients;
//    private List<String> steps;
//
//    public RecipeCard(String title, String imageUrl, int ingredientCount, int stepCount,
//                      String cookTime, List<String> ingredients, List<String> steps) {
//        this.title = title;
//        this.imageUrl = imageUrl;
//        this.ingredientCount = ingredientCount;
//        this.stepCount = stepCount;
//        this.cookTime = cookTime;
//        this.ingredients = ingredients;
//        this.steps = steps;
//    }
//
//    // Getters
//    public String getTitle() { return title; }
//    public String getImageUrl() { return imageUrl; }
//    public int getIngredientCount() { return ingredientCount; }
//    public int getStepCount() { return stepCount; }
//    public String getCookTime() { return cookTime; }
//    public boolean getIngredients() { return ingredients; }
//    public boolean getSteps() { return steps; }
}
